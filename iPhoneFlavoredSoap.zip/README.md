# HumanFlavoredSoap
A simple Proxy I am making that can be used on HTML. You can deploy in Repl.it, or any web hosting site you want.</br>
I do not know very much about coding and stuff so if anyone is willing to help message me on Discord: Rockpods #1744</br>
How to deploy this on repl.it, no account needed. Just press the button below and it will automattically setup the site for free and with no account needed.

[![Run on Repl.it](https://repl.it/badge/github/titaniumnetwork-dev/alloyproxy)](https://repl.it/github/rockpods/HumanFlavoredSoap)

SITE LIST:</br>
https://iphoneflavoredsoap.ga</br>
I am removing support for all sites except main for now. I am doing this so I can focus on updating just one and once I start to get it how I like it so its not updating every five minutes I will open a lot of sites.
<h1>Thanks to Divide and Emerald for helping me.</h1>
